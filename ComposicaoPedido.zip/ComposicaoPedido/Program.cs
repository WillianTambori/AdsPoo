﻿// função main()
using ComposicaoPedido;

Pedido p = new Pedido(1, "24/03/2023", 22, 1 , 54);

Console.WriteLine("Código do pedido: " + p.CodigoPedido + "\tnº Pedidio Item: " + p._PedidoItem.CodigoPedidoItem);